# 嘉立创EDA 专业版 API 速查（中文）

面向「用 `invoke` 在运行中的编辑器里执行 JS」与「写扩展」两种场景。**本文只是索引，签名以 `doc api` 的实时返回为准。**

## 0. 先查再写，别凭记忆写 API

编辑器里跑着的这一版 API 才是真相。任何不确定的类/方法/枚举，先用命令行查：

```bash
node scripts/lceda.mjs doc api                                   # 列出全部类
node scripts/lceda.mjs doc api --class-name DMT_Project          # 列出该类方法
node scripts/lceda.mjs doc api --class-name DMT_Project --method-name createProject  # 完整签名+可运行示例
node scripts/lceda.mjs doc api --class-name EPCB_LayerId         # 枚举取值
node scripts/lceda.mjs doc format --class-name TMSchComponent    # 设计文件格式字段
```

返回里的 `callPath` 就是 `eda` 对象上的属性名：类 `SCH_PrimitiveComponent` → `eda.sch_PrimitiveComponent`。

## 1. 命名空间地图

| 前缀 | 领域 | 典型类 |
| --- | --- | --- |
| `dmt_` | 文档树 / 工程 / 编辑器 | `DMT_Project` `DMT_Board` `DMT_Schematic` `DMT_Pcb` `DMT_EditorControl` |
| `sch_` | 原理图 & 符号 | `SCH_PrimitiveComponent` `SCH_PrimitiveWire` `SCH_Drc` `SCH_Netlist` `SCH_ManufactureData` `SCH_Document` `SCH_SelectControl` |
| `pcb_` | PCB & 封装 | `PCB_PrimitiveComponent` `PCB_PrimitiveLine` `PCB_PrimitivePolyline` `PCB_Document` `PCB_Drc` `PCB_Net` `PCB_ManufactureData` |
| `lib_` | 器件库 | `LIB_LibrariesList` `LIB_Device` `LIB_Symbol` `LIB_Footprint` |
| `sys_` | 系统 | `SYS_FileSystem` `SYS_Environment` `SYS_Dialog` `SYS_Message` `SYS_Storage` `SYS_WebSocket` `SYS_ClientUrl` `SYS_Unit` |

## 2. 高频方法（已核对官方文档）

### 工程与文档

| 调用 | 说明 |
| --- | --- |
| `eda.dmt_Project.createProject(...)` / `openProject(...)` / `getCurrentProjectInfo()` | 建/开工程、取当前工程信息 |
| `eda.dmt_Board.createBoard(...)` / `eda.dmt_Schematic.createSchematic(...)` | 新建板/原理图文档 |
| `eda.dmt_Project.getAllProjectsUuid()` | 列出全部工程 UUID |
| `eda.dmt_EditorControl.openDocument(...)` / `zoomToAllPrimitives()` / `getCurrentRenderedAreaImage()` | 切换文档、缩放到全图、取当前画面 |
| `eda.sch_Document.save()` / `eda.pcb_Document.save()` | 保存（DRC/网表前必须先保存并等待） |

### 原理图

| 调用 | 要点 |
| --- | --- |
| `eda.lib_Device.search(keyword)` | 搜索系统库器件，返回数组，元素可直接传给 create |
| `eda.sch_PrimitiveComponent.create(comp, x, y, subPartName?, rotation?, mirror?, addIntoBom?, addIntoPcb?)` | 放置器件。`rotation`/`mirror` 必须传真实值，硬编码 `0` 会让 90° 器件引脚整体错位 |
| `eda.sch_PrimitiveComponent.createNetFlag(type, net, x, y)` | 网络标识（电源/地等） |
| `eda.sch_PrimitiveComponent.getAllPinsByPrimitiveId(id)` | **取引脚坐标的唯一正确方式**，不要自己按栅格推算 |
| `eda.sch_PrimitiveComponent.modify(id, {x,y,rotation,mirror,designator,name,...})` | 改位置/位号/属性 |
| `eda.sch_PrimitiveComponent.get(ids)` / `.getAllPrimitiveId(type?, allPages?)` / `.delete([ids])` | 查、列、删 |
| `eda.sch_PrimitiveWire.create(...)` / `.getAll()` | 导线 |
| `eda.sch_PrimitiveComponent.getAllPrimitiveId('netflag')` | 按类型过滤（如 `netflag`） |

图元对象读状态：`getState_PrimitiveId()` `getState_Designator()` `getState_X()` `getState_Y()` `getState_AddIntoBom()`。

### 检查与导出

| 需求 | 调用 |
| --- | --- |
| 原理图 DRC | `eda.sch_Drc.check()` |
| PCB DRC | `eda.pcb_Drc.check()` |
| 网表 | `eda.sch_Netlist.getNetlistFile(...)` |
| BOM | `eda.sch_ManufactureData.getBomFile(...)` |
| 原理图截图 | `eda.sch_ManufactureData.getPngFile(name, {width})` |
| Gerber | `eda.pcb_ManufactureData.getGerberFile(...)` |
| 3D / STEP | `eda.pcb_ManufactureData.get3DFile(name, 'step', [...], 'Outfit', true)` |
| 网络名列表 | `eda.pcb_Net.getAllNetsName()` |
| 落盘 | `eda.sys_FileSystem.saveFileToFileSystem(path, file, undefined, true)`（第 4 参 `force` 覆盖） |

`getPngFile` / `getBomFile` 等返回 `File`/`Blob`，写盘前需转 Base64（见 `references/cli-for-ai.md` §6.6）。

## 3. 单位与坐标系（写代码前必读）

| 域 | 约定 |
| --- | --- |
| 原理图 | 单位 **10mil**；原点在图页左下角，**Y 轴向上**；A4 = 1170 × 825 |
| PCB | 单位 **mil**；`layerId=1` 为顶层，`layerId=11` 为板框层 |
| 角度 | API 以**逆时针为正**；写原理图文件时 `COMPONENT.rotation = (360 - API角度) % 360`，PCB 侧 `COMPONENT.angle` 直接等于 API 角度 |

## 4. 易踩的坑

1. **引脚坐标不在栅格上**：常见 698.5 这类半格值。连线两端必须用 `getAllPinsByPrimitiveId()` 返回的原始坐标，四舍五入会把线段打散成一堆 `$xNnn` 短路。
2. **`--ext-uuid eda` 不能省**：省掉后按"独立脚本权限"运行，文件读写和系统接口会被拒。
3. **保存后要等**：`save()` 后等 5–10 秒再做 DRC / 网表 / 渲染，否则拓扑还没算完。DRC 官方建议 8–10 秒。
4. **批量要分批**：一次放 20–25 个器件为宜，`--timeout` 默认 60s，大批量显式调大（上限 1800000ms）。
5. **文件读写范围受限**：`SYS_FileSystem` 只能读写 `config.json` 里 `APP_PROJECT_DIR` 列出的目录及其子目录（默认 `%USERPROFILE%\Documents\LCEDA-Pro`）。导出物写到 `projects\<工程名>\` 最省事。
6. **手写 `.esch2`/`.epcb2` 后对象数不对**：把文件重写一遍让编辑器完整重载，落盘后等 10–15 秒再复核。
7. **路径一律正斜杠**（`C:/Users/...`），反斜杠经 shell 和 JSON 两层转义很容易坏。
8. **器件重复**：随机化初始坐标，避免与画布已有器件重合。

## 5. 现成可跑代码段

`references/cli-for-ai.md` 里是官方给的完整链路，直接照抄改写，不要重新发明：

| 需求 | 章节 |
| --- | --- |
| 建工程 | §8.2 |
| 搜器件 / 放器件 | §8.3 / §8.4 |
| 放网络标识 | §8.5 |
| 画导线 | §8.6 |
| 跑 DRC | §8.7 |
| 导出网表 / BOM / 截图 | §8.8 / §8.9 / §8.10 |
| 保存 | §8.11 |
| 设计 PCB（板框、布局、布线） | §8.12 |
| 直接生成 `.eprj3` 工程文件（不经编辑器） | §9.1–§9.7 |
