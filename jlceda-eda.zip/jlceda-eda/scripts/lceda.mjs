#!/usr/bin/env node
/**
 * lceda.mjs - thin, shell-safe wrapper around the EasyEDA Pro / LCEDA Pro CLI.
 *
 * Why this exists:
 *   - `lceda-pro invoke --code "$(cat step.js)"` mangles quotes, backslashes and
 *     newlines in Git Bash / PowerShell. Here the source is passed as a single
 *     argv element, so nothing gets re-parsed by a shell.
 *   - session ids are bookkeeping noise. This wrapper keeps the last session,
 *     checks it is still alive, and reuses it.
 *   - every call returns the same JSON envelope; this wrapper normalises it,
 *     prints a human summary on stderr and the raw envelope on stdout.
 *
 * Commands:
 *   doctor                        probe the bridge endpoint
 *   open   [--path P] [--headless]  open a project (or a bare editor) -> session
 *   run    --file X.js [--args JSON] [--session ID] [--timeout MS] [--out F]
 *   eval   --code "return 1+1"    same as run, inline source
 *   doc    [api|format|external] [--class-name C] [--method-name M]
 *   sessions                      list sessions
 *   close  [--session ID] [--destroy]
 *   mcp-snippet                   print an mcp.json entry that uses --mcp stdio
 *   path                          print the resolved executable
 *
 * Environment:
 *   LCEDA_BIN   explicit path to lceda-pro / easyeda-pro
 */

import { spawnSync } from "node:child_process";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { homedir, tmpdir } from "node:os";
import { dirname, join, resolve, sep } from "node:path";

const STATE = join(tmpdir(), "lceda-eda-session.json");
const EXE_NAMES =
  process.platform === "win32"
    ? ["lceda-pro.exe", "easyeda-pro.exe"]
    : ["lceda-pro", "easyeda-pro"];

/* ------------------------------------------------------------------ */
/* executable discovery                                                */
/* ------------------------------------------------------------------ */

function hardcodedCandidates() {
  if (process.platform === "win32") {
    return [
      "C:/Program Files/lceda-pro/lceda-pro.exe",
      "C:/Program Files (x86)/lceda-pro/lceda-pro.exe",
      "C:/Program Files/EasyEDA-Pro/easyeda-pro.exe",
      "C:/Program Files (x86)/EasyEDA-Pro/easyeda-pro.exe",
      join(process.env.LOCALAPPDATA || "", "Programs/lceda-pro/lceda-pro.exe"),
      // 本机自定义安装位置（注册表 InstallLocation 实测）
      "D:/jialicEDA/lceda-pro/lceda-pro.exe",
    ];
  }
  if (process.platform === "darwin") {
    return [
      "/Applications/lceda-pro.app/Contents/MacOS/lceda-pro",
      "/Applications/EasyEDA-Pro.app/Contents/MacOS/easyeda-pro",
    ];
  }
  return ["/opt/lceda-pro/lceda-pro", "/usr/bin/lceda-pro", "/usr/local/bin/lceda-pro"];
}

function fromPath() {
  const dirs = (process.env.PATH || "").split(process.platform === "win32" ? ";" : ":");
  for (const d of dirs) {
    if (!d) continue;
    for (const name of EXE_NAMES) {
      const p = join(d, name);
      try {
        if (existsSync(p)) return p;
      } catch {
        /* ignore unreadable PATH entries */
      }
    }
  }
  return null;
}

function resolveExe() {
  if (process.env.LCEDA_BIN) {
    if (!existsSync(process.env.LCEDA_BIN)) {
      die(`LCEDA_BIN points at a missing file: ${process.env.LCEDA_BIN}`);
    }
    return process.env.LCEDA_BIN;
  }
  const found = fromPath();
  if (found) return found;
  for (const c of hardcodedCandidates()) {
    if (c && existsSync(c)) return c;
  }
  die(
    [
      "找不到嘉立创EDA专业版客户端的命令行程序（lceda-pro / easyeda-pro）。",
      "",
      "需要：客户端版本 V4.1.60 及以上（浏览器/在线版不支持命令行与会话功能）。",
      "1. 从 https://lceda.cn/page/download 下载并安装 嘉立创EDA 专业版 客户端",
      "2. 安装后确认 lceda-pro 已加入 PATH，或设置环境变量 LCEDA_BIN 指向可执行文件",
      "   Windows 默认位置: C:/Program Files/lceda-pro/lceda-pro.exe",
      "",
      "安装属于 GUI 操作，必须由用户完成；不要自行下载或安装。",
    ].join("\n"),
  );
}

/* ------------------------------------------------------------------ */
/* cli plumbing                                                        */
/* ------------------------------------------------------------------ */

const EXE = () => resolveExe(); // late-bound so `path`/`doctor` give clear errors

function callCli(args, { quiet = false } = {}) {
  const r = spawnSync(EXE(), args, {
    encoding: "utf8",
    maxBuffer: 64 * 1024 * 1024,
    windowsHide: true,
  });
  if (r.error) {
    const code = r.error.code || "";
    if (code === "ENOENT") {
      die(`无法执行 ${EXE()}（ENOENT）。文件可能已被移动或缺少执行权限。`);
    }
    die(`调用命令行失败: ${r.error.message}`);
  }
  const stdout = (r.stdout || "").trim();
  const stderr = (r.stderr || "").trim();
  const envelope = parseEnvelope(stdout);
  if (!envelope) {
    // Not JSON: probably help text or a crash. Surface it verbatim.
    if (!quiet) {
      if (stdout) process.stderr.write(stdout + "\n");
      if (stderr) process.stderr.write(stderr + "\n");
    }
    return {
      ok: r.status === 0,
      raw: true,
      value: stdout,
      error: r.status === 0 ? undefined : { message: stderr || `exit ${r.status}` },
    };
  }
  if (stderr && !quiet) process.stderr.write(stderr + "\n");
  return envelope;
}

function parseEnvelope(text) {
  if (!text) return null;
  const start = text.indexOf("{");
  if (start < 0) return null;
  try {
    const obj = JSON.parse(text.slice(start));
    return typeof obj === "object" && obj !== null && "ok" in obj ? obj : null;
  } catch {
    return null;
  }
}

function die(msg) {
  process.stderr.write(`错误: ${msg}\n`);
  process.exit(2);
}

function ok(msg) {
  process.stderr.write(`✓ ${msg}\n`);
}

function info(msg) {
  process.stderr.write(`· ${msg}\n`);
}

/* ------------------------------------------------------------------ */
/* session bookkeeping                                                 */
/* ------------------------------------------------------------------ */

function readState() {
  try {
    return JSON.parse(readFileSync(STATE, "utf8"));
  } catch {
    return {};
  }
}

function writeState(s) {
  try {
    writeFileSync(STATE, JSON.stringify(s, null, 2));
  } catch {
    /* state is a convenience, not a requirement */
  }
}

function liveSessions() {
  const env = callCli(["session", "list"], { quiet: true });
  if (!env.ok) return [];
  const list = Array.isArray(env.value) ? env.value : [];
  return list.filter((s) => s && s.status === "alive");
}

function pickSession(explicit) {
  if (explicit) return explicit;
  const st = readState();
  const live = liveSessions();
  if (st.sessionId && live.some((s) => s.sessionId === st.sessionId)) {
    return st.sessionId;
  }
  if (live.length === 1) {
    writeState({ sessionId: live[0].sessionId, path: live[0].path });
    return live[0].sessionId;
  }
  if (live.length > 1) {
    const rows = live
      .map((s) => `  ${s.sessionId}  ${s.path || "(空编辑器)"}  ${s.title || ""}`)
      .join("\n");
    die(
      `存在多个活动会话，请用 --session 指定：\n${rows}\n\n用 \`node lceda.mjs sessions\` 查看。`,
    );
  }
  die("没有活动会话。先运行 `node lceda.mjs open [--path <工程>]` 打开工程。");
}

/* ------------------------------------------------------------------ */
/* argument parsing                                                    */
/* ------------------------------------------------------------------ */

function parseArgs(argv) {
  const flags = {};
  const positional = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith("--")) {
        flags[key] = true;
      } else {
        flags[key] = next;
        i++;
      }
    } else {
      positional.push(a);
    }
  }
  return { flags, positional };
}

function readSource(flags) {
  if (flags.code && flags.file) die("--code 与 --file 只能二选一。");
  if (flags.code) return String(flags.code);
  if (flags.file) {
    const p = resolve(String(flags.file));
    if (!existsSync(p)) die(`源码文件不存在: ${p}`);
    return readFileSync(p, "utf8");
  }
  die("缺少源码：用 --file <x.js> 或 --code \"...\" 提供。");
}

/* ------------------------------------------------------------------ */
/* commands                                                            */
/* ------------------------------------------------------------------ */

function cmdPath() {
  const exe = EXE();
  const v = callCli(["--help"], { quiet: true });
  const first = String(v.raw ? v.value : "").split("\n")[0].trim();
  ok(`可执行文件: ${exe}`);
  if (first) info(`版本信息: ${first}`);
  return v;
}

function cmdDoctor() {
  const env = callCli(["doctor"]);
  if (!env.ok) die("doctor 调用失败，见上方输出。");
  const v = env.value || {};
  if (v.connected) {
    ok(`桥接已连接（endpoint=${v.endpoint}）`);
  } else {
    process.stderr.write(
      [
        `· endpoint=${v.endpoint} connected=false — 当前没有运行中的编辑器窗口。`,
        "  下一步: 打开嘉立创EDA专业版客户端，或在会话里执行 `node lceda.mjs open`。",
        "",
      ].join("\n"),
    );
  }
  return env;
}

function cmdOpen(flags) {
  const args = ["open"];
  if (flags.path) {
    const p = resolve(String(flags.path));
    if (!existsSync(p)) die(`工程路径不存在: ${p}`);
    args.push("--path", p.split(sep).join("/"));
  }
  if (flags.headless) args.push("--headless", "true");
  const env = callCli(args);
  if (!env.ok) return env;
  const sid = env.value?.sessionId;
  if (sid) {
    writeState({ sessionId: sid, path: env.value.path || String(flags.path || "") });
    ok(`会话已就绪: ${sid}`);
  }
  return env;
}

function cmdRun(flags) {
  const sid = pickSession(flags.session ? String(flags.session) : null);
  const code = readSource(flags);
  const args = ["invoke", "--session", sid];
  if (!flags["no-ext"]) args.push("--ext-uuid", "eda");
  args.push("--code", code);
  if (flags.args) args.push("--args", String(flags.args));
  const timeout = flags.timeout ? String(flags.timeout) : "120000";
  args.push("--timeout", timeout);

  process.stderr.write(`· 会话 ${sid}，超时 ${timeout}ms\n`);
  const env = callCli(args);
  if (env.logs?.length) {
    for (const line of env.logs) process.stderr.write(`  [eda] ${line}\n`);
  }
  if (flags.out) {
    const out = resolve(String(flags.out));
    writeFileSync(out, JSON.stringify(env, null, 2));
    info(`原始返回已写入 ${out}`);
  }
  if (env.ok) ok(`调用成功（${env.durationMs ?? "?"}ms）`);
  else {
    const e = env.error || {};
    process.stderr.write(`✗ 调用失败: ${e.code || ""} ${e.message || ""}\n`);
  }
  return env;
}

function cmdDoc(positional, flags) {
  const kind = positional[1] || "api"; // api | format | external
  const args = ["doc", kind];
  if (flags["class-name"]) args.push("--class-name", String(flags["class-name"]));
  if (flags["method-name"]) args.push("--method-name", String(flags["method-name"]));
  return callCli(args);
}

function cmdSessions() {
  const live = liveSessions();
  const st = readState();
  if (!live.length) {
    info("没有活动会话。");
  } else {
    for (const s of live) {
      const mark = s.sessionId === st.sessionId ? "*" : " ";
      process.stderr.write(
        `${mark} ${s.sessionId}  origin=${s.origin || "?"}  ${s.path || "(空编辑器)"}\n`,
      );
    }
  }
  return { ok: true, value: live, logs: [], durationMs: 0 };
}

function cmdClose(flags) {
  const sid = flags.session ? String(flags.session) : readState().sessionId;
  if (!sid) die("没有记录中的会话，用 --session 指定要关闭的会话 ID。");
  const args = ["session", "close", "--session", sid];
  if (flags.destroy) args.push("--destroy");
  const env = callCli(args);
  if (env.ok) {
    writeState({});
    ok(`会话已关闭: ${sid}`);
  }
  return env;
}

function cmdMcpSnippet() {
  const exe = EXE().split(sep).join("/");
  const snippet = {
    mcpServers: {
      jlceda: {
        command: exe,
        args: ["--mcp", "stdio"],
      },
    },
  };
  process.stderr.write(
    "把下面这段合并进 ~/.workbuddy/mcp.json 的 mcpServers，然后在连接器管理里信任并重启：\n",
  );
  process.stdout.write(JSON.stringify(snippet, null, 2) + "\n");
}

/* ------------------------------------------------------------------ */

function main() {
  const [, , cmd, ...rest] = process.argv;
  const { flags, positional } = parseArgs(rest);

  const handlers = {
    path: () => cmdPath(),
    doctor: () => cmdDoctor(),
    open: () => cmdOpen(flags),
    run: () => cmdRun(flags),
    eval: () => cmdRun(flags),
    doc: () => cmdDoc([cmd, ...positional], flags),
    sessions: () => cmdSessions(),
    close: () => cmdClose(flags),
    "mcp-snippet": () => cmdMcpSnippet(),
  };

  if (!cmd || cmd === "--help" || cmd === "-h" || cmd === "help") {
    process.stdout.write(
      [
        "用法: node lceda.mjs <命令> [选项]",
        "",
        "  path                          打印解析到的可执行文件与版本",
        "  doctor                        探测桥接端点",
        "  open [--path P] [--headless]  打开工程/空编辑器，记录会话",
        "  run --file X.js [--args JSON] [--timeout MS] [--out F] [--session ID]",
        "  eval --code \"return 1+1\"      内联执行（等价于 run）",
        "  doc [api|format|external] [--class-name C] [--method-name M]",
        "  sessions                      列出活动会话",
        "  close [--session ID] [--destroy]",
        "  mcp-snippet                   输出 MCP 配置片段",
        "",
        "stdout = 原始 JSON 信封；stderr = 人读摘要。成功退出码 0。",
      ].join("\n") + "\n",
    );
    process.exit(0);
  }

  const h = handlers[cmd];
  if (!h) die(`未知命令: ${cmd}。用 --help 查看可用命令。`);

  const env = h();
  if (env && env.raw) {
    process.exit(env.ok ? 0 : 1);
  }
  process.stdout.write(JSON.stringify(env ?? { ok: true }, null, 2) + "\n");
  process.exit(env && env.ok === false ? 1 : 0);
}

main();
