---
name: jlceda-eda
description: 驱动嘉立创EDA专业版（立创EDA / EasyEDA Pro）完成实际的电路设计工作。通过客户端内置的 lceda-pro / easyeda-pro 命令行桥接，直接在运行中的编辑器里执行扩展 API：读取工程与图元、放置器件与网络标识、画导线、布局布线、铺铜、跑 DRC、导出网表 / BOM / Gerber / STEP / 截图；也能用 easyeda-api-sdk 开发并构建可导入的 .eext 扩展，或按格式规范直接生成 .eprj3 工程文件。当用户提到 嘉立创EDA、立创EDA、EasyEDA、EDA、PCB、原理图、封装、网络标识、布线、走线、铺铜、过孔、DRC、Gerber、网表、BOM、器件选型、扩展开发、.eext、.eprj3 等，或要求"连接 / 操作 / 自动化 EDA"时使用本技能。
agent_created: true
---

# 嘉立创EDA 专业版

把嘉立创EDA专业版当成一个可编程后端：命令行客户端通过本地桥接与运行中的编辑器通信，`invoke` 能在编辑器里执行任意扩展 API 代码。凡是能用 GUI 做的，基本都能从这里做。

## 何时使用

- 用户要**操作正在运行的 EDA**：读图纸、放器件、连线、布线、跑 DRC、导出制造文件
- 用户要**自动化 / 批量**处理工程：批量改位号、批量导出、生成报告
- 用户要**开发 EDA 扩展**（`.eext` 插件）
- 用户要**直接生成 `.eprj3` 工程文件**（不经 GUI，纯代码产出工程）

不适用：浏览器 / 在线版（不支持会话与桥接）；纯电路原理图答疑（不需要动工具就用普通知识回答）。

## 三种执行路径，先选对

| 路径 | 何时用 | 入口 |
| --- | --- | --- |
| **A. 命令行桥接操作**（默认） | 操作已有/新建工程、验证、导出 | `scripts/lceda.mjs` + `references/cli-for-ai.md` |
| **B. 开发扩展 `.eext`** | 用户要一个可复用、可发布的插件 | `references/extension-dev.md` |
| **C. 直接写 `.eprj3` 文件** | 大批量生成工程、需要 git 可 diff | `references/cli-for-ai.md` §9 |

三条路径可以混用。典型做法：API 建工程 → 写业务数据落盘 → 等待重载 → API 验证（DRC / 网表 / 截图）。

## 前置检查（每次动手前）

```bash
node scripts/lceda.mjs path     # 定位可执行文件 + 版本
node scripts/lceda.mjs doctor   # 探测桥接端点
```

判断顺序：

1. **找不到可执行文件** → 停止，让用户安装「嘉立创EDA专业版**客户端**」（V4.1.60+，在线版不行）。安装是 GUI 操作，**不要自己下载或安装**。已装但不在 PATH，用 `LCEDA_BIN` 指向它。
2. **`connected: false`** → 没有运行中的编辑器窗口。让用户打开客户端，或执行 `node scripts/lceda.mjs open`。
3. **版本低于 4.1.60** → 命令行不可用，只能走路径 B / C。

## 核心循环

```bash
# 1. 打开工程（.eprj3 文件夹工程会与磁盘双向同步）；不传 --path 则开空编辑器
node scripts/lceda.mjs open --path "C:/Users/<你>/Documents/LCEDA-Pro/projects/MyBoard/MyBoard.eprj3"

# 2. 在编辑器里执行一段 JS（源码写成文件，避免 shell 吞引号）
node scripts/lceda.mjs run --file step_place.js --args '{"designator":"R1"}' --timeout 180000

# 3. 保存 → 等待 → 验证
node scripts/lceda.mjs eval --code 'await eda.sch_Document.save(); return true;'
# 等 8~10 秒
node scripts/lceda.mjs run --file step_drc.js --out drc.json

# 4. 收尾，别让窗口堆积
node scripts/lceda.mjs close --destroy
```

`run` 写入 stdout 的是完整 JSON 信封，stderr 是人读摘要，退出码 0/1 对应 `ok`。自动化脚本里只判最外层 `ok`。

代码是**异步函数体**，用 `return` 交回结果（会被序列化成 JSON）；可通过 `__CLI__.args` 读 `--args`。

## 硬规则

1. **`invoke` 一律带 `--ext-uuid eda`**（脚本默认已带，`--no-ext` 才关）。省掉会按"独立脚本权限"跑，文件读写和系统接口被拒。
2. **路径用正斜杠** `C:/Users/...`。
3. **只往工程目录里写文件**（`APP_PROJECT_DIR` 及其子目录，默认 `%USERPROFILE%\Documents\LCEDA-Pro`）。
4. **绝不自算引脚坐标**，一律 `getAllPinsByPrimitiveId()` 回读。半格值（如 698.5）四舍五入会把导线打散成短路。
5. **批量放器件按 20~25 个一批**，超时预算才够。
6. **改动后等 5~10 秒**再查状态；DRC 建议等 8~10 秒。
7. **每一步验证**：查 `ok`、查磁盘产物存在，再往下走。把关键返回 JSON 落盘留证。
8. **长耗时操作先告知用户**再做。
9. **用完关会话**（`close --destroy`）。

## 动手前必须问清

1. 目标工程目录 / 要打开哪个工程
2. 要建什么 / 导什么（原理图、PCB、网表、BOM、Gerber、STEP、截图）
3. 改现有工程还是新建
4. 需要用户拍板的值：工程名、器件型号、位号规则 —— **不要自己编**

同时提醒：导入 `.eext`、勾选「允许外部交互」这类 GUI 步骤只能用户自己做。

## 查 API 的正确方式

不要凭记忆写方法名，编辑器里那一版才是真相：

```bash
node scripts/lceda.mjs doc api --class-name SCH_PrimitiveComponent
node scripts/lceda.mjs doc api --class-name SCH_PrimitiveComponent --method-name create
node scripts/lceda.mjs doc api --class-name EPCB_LayerId
node scripts/lceda.mjs doc format --class-name TMSchComponent
```

`references/api-cheatsheet.md` 是中文速查（命名空间地图、高频方法、单位与坐标系、坑位清单），`references/cli-for-ai.md` 是官方完整手册，含 §8 全流程可跑代码和 §9 文件格式。

## 开发扩展（路径 B）

```bash
git clone --depth=1 https://github.com/easyeda/easyeda-api-sdk.git my-extension
cd my-extension && npm install
# 编辑 extension.json（name/displayName/description/publisher/license，uuid 留空自动生成）与 src/index.ts
npm run build     # 产物 build/dist/<name>_v<version>.eext
```

- Node.js ≥ 20.17.0，代码用 TypeScript（`@jlceda/pro-api-types` 提供类型）
- 国内网络拉包失败，改项目级 `.npmrc` 的 `registry=https://registry.npmmirror.com`
- 迭代时每次 `npm run build` 前先在 `extension.json` 升 `version`，然后请用户重新导入
- **导入只能用户做**：顶部菜单 → 高级 → 扩展管理器 → 导入，选 `.eext`
- 完整字段与流程见 `references/extension-dev.md`

## 故障排查

| 现象 | 处理 |
| --- | --- |
| 命令不存在 | 客户端未装或未进 PATH；用 `LCEDA_BIN` 指定，或让用户重装客户端 |
| `doctor` 一直 `connected: false` | 打开客户端窗口；仍不行让用户确认版本 ≥ 4.1.60 |
| `ok: false` + `EXECUTION_ERROR` | 代码抛错。先查 `doc api` 的签名与参数，再查单位/坐标系 |
| 超时 | 调大 `--timeout`（上限 1800000），并把批量拆小 |
| 文件读写被拒 | 目标不在 `APP_PROJECT_DIR` 内，或漏了 `--ext-uuid eda` |
| DRC 结果为空/不准 | `save()` 后没等够时间，重新等 8~10 秒再跑 |
| 多个会话 | `sessions` 看列表，用 `--session` 指定 |
| 想当 MCP 工具用 | `node scripts/lceda.mjs mcp-snippet` 生成配置，合并进 `~/.workbuddy/mcp.json` 后在连接器管理里信任并重启 |

## 边界

- 不擅自装软件、不提权、不改全局 npm/系统配置
- 不擅自改用户已有工程的结构性内容（删器件、删网络）——先说明影响
- GUI 步骤（导入扩展、勾选外部交互）交给用户

## 捆绑资源

- `scripts/lceda.mjs` — 命令行封装：定位可执行文件、复用会话、安全传参、统一 JSON 信封
- `references/cli-for-ai.md` — 官方 AI 手册（命令、全流程代码、`.eprj3` 格式）
- `references/api-cheatsheet.md` — 中文速查：命名空间、高频方法、坐标系、坑位
- `references/extension-dev.md` — 官方扩展工程初始化指南
